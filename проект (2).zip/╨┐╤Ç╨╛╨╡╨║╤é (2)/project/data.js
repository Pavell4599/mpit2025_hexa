const companies = [
  {name:"ООО «КалининградСофт»", inn:"3906012345", city:"Калининград", revenue:"187 млн", employees:42, accredited:true},
  {name:"ИП Иванов А. В.", inn:"3906123456", city:"Калининград", revenue:"12 млн", employees:3, accredited:false},
  {name:"АО «БалтТех»", inn:"3906234567", city:"Калининград", revenue:"1.2 млрд", employees:287, accredited:true},
  {name:"ООО «АмберКод»", inn:"3906345678", city:"Советск", revenue:"84 млн", employees:28, accredited:true},
  {name:"ООО «ВебСтудия 39»", inn:"3906456789", city:"Калининград", revenue:"46 млн", employees:19, accredited:false},
  {name:"ООО «СмартСистемс»", inn:"3906567890", city:"Черняховск", revenue:"312 млн", employees:98, accredited:true},
  {name:"ИП Петров С. Н.", inn:"3906678901", city:"Гурьевск", revenue:"8 млн", employees:1, accredited:false},
  {name:"ООО «НекстГен»", inn:"3906789012", city:"Калининград", revenue:"523 млн", employees:156, accredited:true},
  {name:"ООО «КодМастер»", inn:"3906890123", city:"Светлогорск", revenue:"67 млн", employees:31, accredited:false},
  {name:"ЗАО «ИТ-Лаборатория»", inn:"3906901234", city:"Калининград", revenue:"940 млн", employees:312, accredited:true}
];

