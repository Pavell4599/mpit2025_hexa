# -*- coding: utf-8 -*-
import pandas as pd
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)

excel_filename = "Dop_materialy_Razrabotka_analiticheskoj_sistemy_Akkreditovannye (2).xlsx"
excel_path = os.path.join(project_root, excel_filename)

if not os.path.exists(excel_path):
    excel_path = os.path.join(current_dir, excel_filename)
if not os.path.exists(excel_path):
    raise FileNotFoundError("Excel не найден!")

print(f"Загружаем: {excel_path}")

df = pd.read_excel(excel_path, sheet_name="Аккредитованные ИТ-компании")

df.columns = ["full_name","short_name","inn","date_reg","inn2","director_fio","okved",
              "revenue_rub","expenses_rub","taxes_rub","tax_year","employees",
              "employees_year","usn"]

df = df.dropna(subset=['inn']).copy()
df['inn'] = df['inn'].astype(str).str.strip().str.zfill(10)

# Города
city_map = {"3906":"Калининград","3900":"Калининград","3901":"Калининград","3902":"Калининград",
            "3903":"Советск","3904":"Черняховск","3905":"Гусев","3907":"Калининград",
            "3908":"Светлый","3909":"Балтийск","3910":"Гвардейск","3911":"Неман",
            "3912":"Зеленоградск","3913":"Гурьевск","3917":"Светлогорск"}

def get_city(inn):
    for p in city_map:
        if inn.startswith(p): return city_map[p]
    return "Калининград"

# Умная обработка выручки (теперь миллиарды будут!)
def format_revenue(rub):
    if pd.isna(rub) or str(rub).strip() in ("", "Нет данных", "0"):
        return "0 млн"
    try:
        n = float(rub)
        if n >= 1_000_000_000:
            return f"{n/1_000_000_000:.2f}".rstrip("0").rstrip(".") + " млрд"
        elif n >= 1_000_000:
            return f"{int(round(n/1_000_000))} млн"
        else:
            return f"{int(n/1000)} тыс."
    except:
        return "0 млн"

companies = []
for _, row in df.iterrows():
    inn = str(row['inn'])
    if len(inn) < 10: continue

    name = str(row.get('short_name') or row.get('full_name') or "—").strip()
    name = name.replace('"', '\\"').replace('\n', ' ')

    revenue_val = row['revenue_rub']
    revenue_str = format_revenue(revenue_val)

    # Если выручка нулевая — попробуем взять из столбца "expenses_rub" (иногда там есть данные)
    if revenue_str == "0 млн" and pd.notna(row['expenses_rub']):
        revenue_str = format_revenue(row['expenses_rub'])

    employees = int(row['employees']) if pd.notna(row['employees']) and str(row['employees']) != "Нет данных" else 1

    companies.append({
        "name": name,
        "inn": inn,
        "city": get_city(inn),
        "revenue": revenue_str,
        "employees": employees,
        "accredited": True
    })

# Сортировка
companies.sort(key=lambda x: float(x['revenue'].split()[0].replace(',', '.')) * (1000 if "млрд" in x['revenue'] else 1), reverse=True)

# Запись
output_path = os.path.join(current_dir, "data.js")
with open(output_path, "w", encoding="utf-8") as f:
    f.write("const companies = [\n")
    for c in companies:
        f.write(f'  {{name:"{c["name"]}", inn:"{c["inn"]}", city:"{c["city"]}", revenue:"{c["revenue"]}", employees:{c["employees"]}, accredited:true}},\n')
    f.write("];\n")

print("\nГОТОВО! Реальные данные ИТ Калининграда 2024–2025")
print(f"Компаний в базе: {len(companies)}")
print(f"Файл обновлён: data.js\n")
print("ТОП-10 лидеров по выручке:")
for i, c in enumerate(companies[:10], 1):
    print(f"{i:2}. {c['revenue']:>12}  —  {c['name']}")