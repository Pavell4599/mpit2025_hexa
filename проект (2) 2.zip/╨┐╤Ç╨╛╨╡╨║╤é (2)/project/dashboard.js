const results = document.getElementById('results');
const searchInput = document.getElementById('searchInput');
const sidebar = document.getElementById('sidebar');
const menuToggle = document.querySelector('.menu-toggle');

let currentFilter = 'all';
let currentSort = null; // null | 'revenue' | 'employees'

function parseRevenue(str) {
  const num = parseFloat(str.replace(/[^\d.]/g, ''));
  return str.includes('млрд') ? num * 1000 : num;
}

function render(list) {
  if (!list || list.length === 0) {
    results.innerHTML = '<p style="text-align:center;color:#aaa;padding:100px;font-size:19px">Ничего не найдено :(</p>';
    return;
  }

  results.innerHTML = list.map(c => `
    <div class="card">
      <h3>${c.name}</h3>
      <p><strong>ИНН:</strong> ${c.inn} • ${c.city}</p>
      <p>
        <strong>Выручка 2024:</strong> 
        <span class="highlight-revenue${currentSort === 'revenue' ? ' active' : ''}">${c.revenue}</span> • 
        <span class="highlight-employees${currentSort === 'employees' ? ' active' : ''}">${c.employees}</span> чел.
      </p>
      <span class="tag ${c.accredited ? 'acc' : 'no'}">
        ${c.accredited ? 'Аккредитована' : 'Не аккредитована'}
      </span>
    </div>
  `).join('');
}

function updateStats() {
  const total = companies.length;
  const accredited = companies.filter(c => c.accredited).length;
  const revenue = companies.reduce((s, c) => s + parseRevenue(c.revenue), 0);
  const employees = companies.reduce((s, c) => s + c.employees, 0);

  document.getElementById('totalCompanies').textContent = total;
  document.getElementById('accreditedCount').textContent = accredited;
  document.getElementById('totalRevenue').textContent = revenue >= 1000 
    ? (revenue/1000).toFixed(1) + ' млрд ₽' 
    : Math.round(revenue) + ' млн ₽';
  document.getElementById('totalEmployees').textContent = employees > 999 
    ? (employees/1000).toFixed(1)+' тыс.' : employees;

  document.getElementById('countAll').textContent = total + ' компаний';
  document.getElementById('countAcc').textContent = accredited + ' компаний';
  document.getElementById('countNo').textContent = (total - accredited) + ' компаний';
}

function applyFilterAndSort() {
  let filtered = [...companies];

  if (currentFilter === 'acc') filtered = filtered.filter(c => c.accredited);
  if (currentFilter === 'no') filtered = filtered.filter(c => !c.accredited);

  const term = searchInput.value.trim().toLowerCase();
  if (term) {
    filtered = filtered.filter(c =>
      c.name.toLowerCase().includes(term) ||
      c.inn.includes(term) ||
      c.city.toLowerCase().includes(term)
    );
  }

  if (currentSort === 'revenue') {
    filtered.sort((a, b) => parseRevenue(b.revenue) - parseRevenue(a.revenue));
  } else if (currentSort === 'employees') {
    filtered.sort((a, b) => b.employees - a.employees);
  }

  render(filtered);
}

document.addEventListener('DOMContentLoaded', () => {
  updateStats();
  render(companies);

  // Фильтры
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.filter;
      applyFilterAndSort();
      sidebar.classList.remove('open');
    });
  });

  searchInput.addEventListener('input', applyFilterAndSort);

  // Сортировка по выручке
  const sortRevenueBtn = document.getElementById('sortRevenue');
  sortRevenueBtn.addEventListener('click', () => {
    currentSort = currentSort === 'revenue' ? null : 'revenue';
    sortRevenueBtn.classList.toggle('active', currentSort === 'revenue');
    document.getElementById('sortEmployees').classList.remove('active');
    applyFilterAndSort();
  });

  // Сортировка по сотрудникам
  const sortEmployeesBtn = document.getElementById('sortEmployees');
  sortEmployeesBtn.addEventListener('click', () => {
    currentSort = currentSort === 'employees' ? null : 'employees';
    sortEmployeesBtn.classList.toggle('active', currentSort === 'employees');
    sortRevenueBtn.classList.remove('active');
    applyFilterAndSort();
  });

  // Бургер-меню
  menuToggle.addEventListener('click', e => { e.stopPropagation(); sidebar.classList.toggle('open'); });
  document.querySelector('.close-sidebar').addEventListener('click', () => sidebar.classList.remove('open'));
  document.addEventListener('click', e => {
    if (sidebar.classList.contains('open') && !sidebar.contains(e.target) && e.target !== menuToggle) {
      sidebar.classList.remove('open');
    }
  });

  // Анимация карточек
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, { threshold: 0.1 });

  const applyAnimation = () => {
    document.querySelectorAll('#results .card').forEach(card => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(30px)';
      card.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
      observer.observe(card);
    });
  };

  applyAnimation();
  const originalRender = render;
  render = function(list) {
    originalRender(list);
    setTimeout(applyAnimation, 50);
  };
});